<input
  type="text"
  name="name"
  value={values.name}
  onChange={handleChange}
  placeholder="이름을 입력하세요"
  className="
    w-full
    px-4 py-3
    border border-gray-300
    rounded-lg
    focus:outline-none
    focus:ring-2
    focus:ring-orange-400
  "
/>