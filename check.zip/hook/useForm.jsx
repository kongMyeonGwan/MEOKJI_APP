import { useState } from 'react';

function useForm(initialValues){
    const [values, setValues] = useState(initialValues);

    // 모든 입력창이 같이 쓰는 change 핸들러
  const handleChange = (e) => {
    // e.target = 방금 바뀐 입력창(DOM). 필요한 속성만 꺼낸다
    //   name    : 입력창의 name 속성 → state의 어떤 칸을 바꿀지 알려주는 "주소"
    //   value   : 입력된 값 (항상 문자열!)
    //   type    : 'text', 'checkbox', 'radio' ...
    //   checked : 체크박스가 체크됐는지 (true/false)
    const { name, value, type, checked } = e.target;

    setValues((prev) => ({
      ...prev,                                           // 나머지 값은 그대로 복사
      [name]: type === 'checkbox' ? checked : value,     // [name] = 변수 이름을 키로 쓰는 문법
    }));
  };

  // 처음 값으로 되돌리기
  const reset = () => setValues(initialValues);

  // 컴포넌트에서 쓸 것들을 객체로 돌려준다
  return { values, handleChange, reset };
}

export default useForm;
