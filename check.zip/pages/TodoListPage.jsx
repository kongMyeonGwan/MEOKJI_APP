// pages/TodoListPage.jsx  (기존 TodoList.jsx의 목록 부분)
import { Link } from "react-router-dom";

const TodoListPage = ({ todos, onDelete, onToggle }) => {
  if (todos.length === 0) {
    return (
      <p className="py-8 text-center text-gray-500">
        할 일이 없습니다.{" "}
        <Link
          to="/add"
          className="text-blue-500 font-semibold hover:text-blue-700 hover:underline"
        >
          새 할 일 추가하기
        </Link>
      </p>
    );
  }

  return (
    <ul className="space-y-3">
      {todos.map((todo) => (
        // index 대신 고유 id를 key로 사용 (삭제 시에도 항목이 뒤섞이지 않음)
        <li
          key={todo.id}
          className="flex items-center gap-3 p-4 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition"
        >
          <input
            type="checkbox"
            checked={todo.done}
            onChange={() => onToggle(todo.id)}
            className="w-5 h-5 cursor-pointer accent-blue-500"
          />

          {/* 클릭하면 /todos/1727000000000 같은 상세 주소로 이동 */}
          <Link
            to={`/todos/${todo.id}`}
            className={`flex-1 text-gray-700 hover:text-blue-500 transition ${
              todo.done ? "line-through text-gray-400" : ""
            }`}
          >
            {todo.text}
          </Link>

          <button
            onClick={() => onDelete(todo.id)}
            className="px-4 py-2 bg-red-500 text-white text-sm font-semibold rounded-lg hover:bg-red-600 active:bg-red-700 transition"
          >
            Delete
          </button>
        </li>
      ))}
    </ul>
  );
};

export default TodoListPage;