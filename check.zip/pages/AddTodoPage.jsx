// pages/AddTodoPage.jsx  (기존 TodoList.jsx의 입력 부분)
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const AddTodoPage = ({ onAdd }) => {
  // 입력 중인 값은 이 페이지에서만 쓰므로 여기서 관리
  const [newTodo, setNewTodo] = useState("");
  const navigate = useNavigate();

  const handleAddTodo = () => {
    if (newTodo.trim() === "") return; // 아무것도 안썼다면 리턴
    onAdd(newTodo.trim()); // 추가
    setNewTodo(""); // 입력칸 비우고
    navigate("/"); // 추가 후 목록 페이지로 이동
  };

  return (
    <div className="flex gap-3">
      <input
        type="text"
        value={newTodo}
        onChange={(e) => setNewTodo(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && handleAddTodo()}
        placeholder="Add a new task"
        autoFocus
        className="flex-1 px-4 py-3 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
      />

      <button
        onClick={handleAddTodo}
        className="px-6 py-3 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 active:bg-blue-700 transition"
      >
        Add
      </button>
    </div>
  );
};

export default AddTodoPage;