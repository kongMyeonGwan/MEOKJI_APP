// pages/NotFoundPage.jsx
import { Link, useLocation } from "react-router-dom";

const NotFoundPage = () => {
  const location = useLocation();

  return (
    <div className="detail">
      <p>페이지를 찾을 수 없습니다: {location.pathname}</p>
      <Link to="/">목록으로</Link>
    </div>
  );
};

export default NotFoundPage;