// pages/TodoDetailPage.jsx
import { useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";

const TodoDetailPage = ({ todos, onDelete, onToggle, onUpdate }) => {
  const { id } = useParams(); // 주소의 :id 값 (문자열)
  const navigate = useNavigate();

  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState("");

  // 주소의 id는 문자열이므로 숫자로 바꿔서 비교
  const todo = todos.find((t) => t.id === Number(id));

  // 없는 id로 들어온 경우 (삭제됐거나 주소를 잘못 입력)
  if (!todo) {
    return (
      <div className="p-6 bg-white border border-gray-200 rounded-xl shadow-sm text-center">
        <p className="mb-4 text-gray-600">
          해당 할 일을 찾을 수 없습니다.
        </p>

        <Link
          to="/"
          className="text-blue-500 font-semibold hover:text-blue-700 hover:underline"
        >
          목록으로
        </Link>
      </div>
    );
  }

  const startEdit = () => {
    setEditText(todo.text);
    setEditing(true);
  };

  const saveEdit = () => {
    if (editText.trim() === "") return;
    onUpdate(todo.id, editText.trim());
    setEditing(false);
  };

  const handleDelete = () => {
    onDelete(todo.id);
    navigate("/", { replace: true }); // 삭제된 상세 페이지로 뒤로가기 되지 않도록 replace
  };

  return (
    <div className="p-6 bg-white border border-gray-200 rounded-xl shadow-sm">
      {editing ? (
        <div className="flex gap-3 mb-6">
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            autoFocus
            className="flex-1 px-4 py-3 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />

          <button
            onClick={saveEdit}
            className="px-5 py-3 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 transition"
          >
            저장
          </button>

          <button
            onClick={() => setEditing(false)}
            className="px-5 py-3 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 transition"
          >
            취소
          </button>
        </div>
      ) : (
        <h2
          className={`mb-5 text-2xl font-bold ${
            todo.done
              ? "line-through text-gray-400"
              : "text-gray-800"
          }`}
        >
          {todo.text}
        </h2>
      )}

      <p className="mb-2 text-gray-700">
        상태: {todo.done ? "✅ 완료" : "⏳ 진행 중"}
      </p>

      <p className="mb-6 text-sm text-gray-400">
        등록: {todo.createdAt}
      </p>

      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => onToggle(todo.id)}
          className="px-4 py-2 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition"
        >
          {todo.done ? "진행 중으로" : "완료 처리"}
        </button>

        {!editing && (
          <button
            onClick={startEdit}
            className="px-4 py-2 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 transition"
          >
            수정
          </button>
        )}

        <button
          onClick={handleDelete}
          className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition"
        >
          Delete
        </button>

        <button
          onClick={() => navigate(-1)}
          className="px-4 py-2 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 transition"
        >
          뒤로
        </button>
      </div>
    </div>
  );
};

export default TodoDetailPage;