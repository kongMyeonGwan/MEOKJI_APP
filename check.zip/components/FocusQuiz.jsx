import { useRef, useEffect, useState } from 'react';

function FocusQuiz() {
    const inputRef = useRef(null);
    const [message, setMessage] = useState('');

    useEffect(() => {
        inputRef.current.focus();
    }, []); // 시작하자마자 딱 한 번만 수행

    const check = () => {
        if (inputRef.current.value === '4') {
            setMessage('🎉 정답! 귤 2개 + 귤 2개 = 4개');
        } else {
            setMessage('😅 땡! 다시 해 보세요');
            inputRef.current.select(); // 틀리면 입력한 글자 전체 선택
        }
    };

    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-lg p-8 text-center">

                <h2 className="text-2xl font-bold text-gray-800 mb-6">
                    🎯 1- 자동 포커스 퀴즈
                </h2>

                <p className="text-3xl mb-6">
                    🍊🍊 + 🍊🍊 = ?
                </p>

                <input
                    ref={inputRef}
                    placeholder="정답 입력"
                    className="
                        w-full
                        border-2 border-gray-300
                        rounded-lg
                        px-4 py-3
                        text-center text-lg
                        outline-none
                        focus:border-blue-500
                        focus:ring-2
                        focus:ring-blue-200
                        transition
                    "
                />

                <div className="flex gap-3 mt-5">
                    <button
                        onClick={check}
                        className="
                            flex-1
                            bg-blue-500
                            text-white
                            font-semibold
                            py-3
                            rounded-lg
                            hover:bg-blue-600
                            transition
                            cursor-pointer
                        "
                    >
                        확인
                    </button>

                    <button
                        onClick={() => inputRef.current.focus()}
                        className="
                            flex-1
                            bg-gray-600
                            text-white
                            font-semibold
                            py-3
                            rounded-lg
                            hover:bg-gray-700
                            transition
                            cursor-pointer
                        "
                    >
                        커서 다시 넣기
                    </button>
                </div>

                <p className="mt-6 text-lg font-semibold text-gray-700 min-h-7">
                    {message}
                </p>

            </div>
        </div>
    );
}

export default FocusQuiz;