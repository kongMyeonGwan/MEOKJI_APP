// DOM을 직접 바꾸면 React와 싸운다
import { useRef, useState } from 'react';


// ❌ 나쁜 예: React가 그리는 글자를 innerHTML로 덮어쓰기
function BadCounter() {

  const [count, setCount] = useState(0);
  const textRef = useRef(null);

  return (
    <div className="p-6 bg-red-50 border-2 border-red-300 rounded-xl">

      <h3 className="text-xl font-bold text-red-600 mb-4">
        ❌ 나쁜 예 (innerHTML 직접 수정)
      </h3>

      <p
        ref={textRef}
        className="text-2xl font-semibold mb-5"
      >
        🍊 귤 {count}개
      </p>

      <div className="flex gap-3">

        <button
          onClick={() => setCount(count + 1)}
          className="
            px-4 py-2
            bg-orange-500
            text-white
            font-semibold
            rounded-lg
            hover:bg-orange-600
            transition
            cursor-pointer
          "
        >
          귤 +1
        </button>

        <button
          onClick={() => (
            textRef.current.innerHTML = '😈 몰래 바꿈!'
          )}
          className="
            px-4 py-2
            bg-red-500
            text-white
            font-semibold
            rounded-lg
            hover:bg-red-600
            transition
            cursor-pointer
          "
        >
          DOM 직접 수정
        </button>

      </div>

    </div>
  );
}


// ✅ 좋은 예: 화면에 보이는 값은 state로 관리
function GoodCounter() {

  const [count, setCount] = useState(0);
  const [text, setText] = useState('');

  return (
    <div className="p-6 bg-green-50 border-2 border-green-300 rounded-xl">

      <h3 className="text-xl font-bold text-green-600 mb-4">
        ✅ 좋은 예 (state로 변경)
      </h3>

      <p className="text-2xl font-semibold mb-5">
        {text || `🍊 귤 ${count}개`}
      </p>

      <div className="flex gap-3">

        <button
          onClick={() => {
            setCount(count + 1);
            setText('');
          }}
          className="
            px-4 py-2
            bg-orange-500
            text-white
            font-semibold
            rounded-lg
            hover:bg-orange-600
            transition
            cursor-pointer
          "
        >
          귤 +1
        </button>

        <button
          onClick={() => setText('😇 state로 바꿈!')}
          className="
            px-4 py-2
            bg-green-500
            text-white
            font-semibold
            rounded-lg
            hover:bg-green-600
            transition
            cursor-pointer
          "
        >
          state로 수정
        </button>

      </div>

    </div>
  );
}


function GoodBad() {

  return (
    <div className="max-w-3xl mx-auto p-8 bg-white rounded-2xl shadow-lg">

      <h2 className="text-2xl font-bold text-gray-800 mb-3">
        ⚖️ 7.4 DOM 조작 좋은 예 vs 나쁜 예
      </h2>

      <p className="text-gray-600 mb-7">
        양쪽 모두 [수정] 버튼을 누른 다음 [귤 +1]을 눌러 보세요.
      </p>

      <div className="grid gap-6">

        <BadCounter />

        <GoodCounter />

      </div>

    </div>
  );
}

export default GoodBad;