import { useState } from 'react'
import useForm from '../hook/useForm'

// 재사용 틀: 라벨 + 입력창 + 에러
function CustFormField({ label, required, error, children }) {
    return (
        <div className="mb-6">
            <label className="block font-semibold text-gray-700">
                {label}

                {required && (
                    <span className="ml-1 text-red-500">*</span>
                )}

                {children}
            </label>

            {error && (
                <p className="mt-2 text-sm font-medium text-red-500">
                    {error}
                </p>
            )}
        </div>
    );
}


// 재사용 입력창
function Input({ hasError, ...props }) {
    return (
        <input
            className={`
                block w-full mt-2 px-4 py-3
                border rounded-lg
                font-normal
                outline-none
                transition
                ${
                    hasError
                        ? "border-red-500 focus:ring-2 focus:ring-red-300"
                        : "border-gray-300 focus:border-orange-400 focus:ring-2 focus:ring-orange-200"
                }
            `}
            {...props}
        />
    );
}


// 유효성 검사
const validate = (v) => {
    const errors = {};

    if (!v.nickname) {
        errors.nickname = "닉네임을 입력하세요.";
    } else if (v.nickname.length < 2) {
        errors.nickname = "닉네임은 2자 이상이에요.";
    }

    if (v.password.length < 8) {
        errors.password = "비밀번호는 8자 이상이에요.";
    }

    if (v.confirm !== v.password) {
        errors.confirm = "비밀번호가 서로 달라요.";
    }

    return errors;
};


function CustomFields() {

    const { values, handleChange } = useForm({
        nickname: "",
        password: "",
        confirm: "",
    });

    const [touched, setTouched] = useState({});
    const [done, setDone] = useState(false);


    // input에서 빠져나오면 해당 input을 건드렸다고 기록
    const handleBlur = (e) => {
        setTouched((prev) => ({
            ...prev,
            [e.target.name]: true
        }));
    };


    // 현재 입력값으로 유효성 검사
    const errors = validate(values);


    // 해당 input을 건드렸을 때만 에러를 반환
    const errorOf = (name) => {
        return touched[name] ? errors[name] : "";
    };


    const handleSubmit = (e) => {
        e.preventDefault();

        // 제출하면 모든 input을 건드린 것으로 처리
        setTouched({
            nickname: true,
            password: true,
            confirm: true
        });

        // errors가 하나도 없다면 가입 성공
        setDone(Object.keys(errors).length === 0);
    };


    return (
        <div className="
            max-w-xl mx-auto mt-10 p-8
            bg-white
            border border-orange-100
            rounded-2xl
            shadow-lg
        ">

            <h2 className="
                mb-8
                text-2xl
                font-bold
                text-center
                text-orange-500
            ">
                🍊 커스텀 폼 컴포넌트 - 귤 클럽 가입
            </h2>


            <form onSubmit={handleSubmit}>

                <CustFormField
                    label="닉네임"
                    required
                    error={errorOf('nickname')}
                >
                    <Input
                        name="nickname"
                        value={values.nickname}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        hasError={!!errorOf('nickname')}
                        placeholder="닉네임을 입력하세요"
                    />
                </CustFormField>


                <CustFormField
                    label="비밀번호"
                    required
                    error={errorOf('password')}
                >
                    <Input
                        name="password"
                        type="password"
                        autoComplete="new-password"
                        value={values.password}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        hasError={!!errorOf('password')}
                        placeholder="8자 이상 입력하세요"
                    />
                </CustFormField>


                <CustFormField
                    label="비밀번호 확인"
                    required
                    error={errorOf('confirm')}
                >
                    <Input
                        name="confirm"
                        type="password"
                        autoComplete="new-password"
                        value={values.confirm}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        hasError={!!errorOf('confirm')}
                        placeholder="비밀번호를 다시 입력하세요"
                    />
                </CustFormField>


                <button
                    type="submit"
                    className="
                        w-full py-3 mt-2
                        bg-orange-500
                        text-white
                        font-bold
                        rounded-lg
                        hover:bg-orange-600
                        active:bg-orange-700
                        transition-colors
                    "
                >
                    가입하기
                </button>

            </form>


            {done && (
                <p className="
                    mt-6 p-4
                    text-center
                    font-semibold
                    text-green-700
                    bg-green-50
                    border border-green-200
                    rounded-lg
                ">
                    🎉 {values.nickname}님, 귤 클럽 가입을 환영해요!
                </p>
            )}

        </div>
    );
}


export default CustomFields;