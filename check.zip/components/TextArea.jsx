import { useState } from "react";

const Max = 100;

const KINDS = [
    { value: "gamgyul", label: "🍊 감귤", price: 15000 },
    { value: "hallabong", label: "🍊 한라봉", price: 35000 },
    { value: "cheonhye", label: "🍊 천혜향", price: 30000 },
    { value: "redhyang", label: "🍊 레드향", price: 28000 },
];

function TextareaSelect() {

    const [kind, setKind] = useState("hallabong");
    const [review, setReview] = useState("");

    // 현재 선택한 품종 찾기
    const selected = KINDS.find((k) => k.value === kind);

    return (
        <div className="max-w-2xl mx-auto">

            {/* 제목 */}
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
                📦 textarea와 select - 귤 후기 남기기
            </h2>


            {/* 품종 선택 */}
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-5">

                <label
                    htmlFor="kind"
                    className="block text-sm font-semibold text-gray-700 mb-2"
                >
                    🍊 품종
                </label>

                <select
                    id="kind"
                    value={kind}
                    onChange={(e) => setKind(e.target.value)}
                    className="
                        w-full
                        px-4
                        py-3
                        bg-white
                        border
                        border-gray-300
                        rounded-lg
                        text-gray-800
                        outline-none
                        cursor-pointer
                        focus:border-orange-500
                        focus:ring-2
                        focus:ring-orange-200
                        transition
                    "
                >
                    {KINDS.map((k) => (
                        <option
                            key={k.value}
                            value={k.value}
                        >
                            {k.label}
                        </option>
                    ))}
                </select>


                {/* 가격 */}
                <div className="mt-4 bg-orange-50 border border-orange-100 rounded-lg p-4">

                    <p className="text-sm text-gray-500">
                        5kg 가격
                    </p>

                    <p className="text-xl font-bold text-orange-600 mt-1">
                        {selected.price.toLocaleString()}원
                    </p>

                </div>

            </div>


            {/* 후기 작성 */}
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">

                <label
                    htmlFor="review"
                    className="block text-sm font-semibold text-gray-700 mb-2"
                >
                    ✏️ 후기
                </label>

                <textarea
                    id="review"
                    value={review}
                    onChange={(e) => setReview(e.target.value)}
                    rows={4}
                    maxLength={Max}
                    placeholder="달달했나요?"

                    className="
                        w-full
                        px-4
                        py-3
                        bg-white
                        border
                        border-gray-300
                        rounded-lg
                        text-gray-800
                        outline-none
                        resize-none
                        focus:border-orange-500
                        focus:ring-2
                        focus:ring-orange-200
                        transition
                    "
                />


                {/* 글자수 */}
                <div className="flex justify-end mt-2">

                    <p
                        className={
                            review.length > 90
                                ? "text-sm font-semibold text-red-500"
                                : "text-sm text-gray-400"
                        }
                    >
                        {review.length} / {Max} 자
                    </p>

                </div>

            </div>

        </div>
    );
}

export default TextareaSelect;