import { useState } from "react";

const formatPhone = (value) => {
    const n = value.replace(/\D/g, "").slice(0, 11);

    if (n.length <= 3) return n;
    if (n.length <= 7) return `${n.slice(0, 3)}-${n.slice(3)}`;

    return `${n.slice(0, 3)}-${n.slice(3, 7)}-${n.slice(7)}`;
};


function FormEvents() {

    const [phone, setPhone] = useState("");
    const [logs, setLogs] = useState([]);

    // 새 로그를 맨 위에 추가하고 최근 6개만 남기기
    const addLog = (text) =>
        setLogs((prev) => [text, ...prev].slice(0, 6));


    return (
        <div className="max-w-2xl mx-auto">

            {/* 제목 */}
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
                🎬 폼 이벤트 — 이벤트 관찰 카메라
            </h2>


            {/* 폼 */}
            <form
                className="bg-gray-50 border border-gray-200 rounded-xl p-6"

                onSubmit={(e) => {
                    e.preventDefault();

                    addLog(
                        `📨 onSubmit: ${phone || "빈 값"} 제출`
                    );
                }}

                onReset={() => {
                    setPhone("");
                    addLog("🧹 onReset: 초기화");
                }}
            >

                {/* 전화번호 */}
                <div className="flex flex-col gap-2 mb-5">

                    <label className="font-semibold text-gray-700">
                        전화번호
                    </label>

                    <input
                        type="tel"
                        value={phone}
                        placeholder="숫자만 입력"

                        className="
                            w-full
                            px-4
                            py-3
                            border
                            border-gray-300
                            rounded-lg
                            outline-none
                            bg-white
                            text-gray-800
                            focus:border-blue-500
                            focus:ring-2
                            focus:ring-blue-200
                            transition
                        "

                        onChange={(e) => {

                            const formatted =
                                formatPhone(e.target.value);

                            setPhone(formatted);

                            addLog(
                                `✏️ onChange: ${formatted}`
                            );
                        }}

                        onFocus={() =>
                            addLog("👀 onFocus: 입력창 선택")
                        }

                        onBlur={() =>
                            addLog("👋 onBlur: 입력창 떠남")
                        }

                        onKeyDown={(e) => {

                            if (e.key === "Enter") {
                                addLog(
                                    "⌨️ onKeyDown: Enter 키"
                                );
                            }

                        }}
                    />

                </div>


                {/* 버튼 */}
                <div className="flex gap-3">

                    <button
                        type="submit"
                        className="
                            px-5
                            py-2.5
                            bg-blue-500
                            text-white
                            font-semibold
                            rounded-lg
                            hover:bg-blue-600
                            active:bg-blue-700
                            transition
                            cursor-pointer
                        "
                    >
                        제출
                    </button>


                    <button
                        type="reset"
                        className="
                            px-5
                            py-2.5
                            bg-gray-200
                            text-gray-700
                            font-semibold
                            rounded-lg
                            hover:bg-gray-300
                            active:bg-gray-400
                            transition
                            cursor-pointer
                        "
                    >
                        리셋
                    </button>

                </div>

            </form>


            {/* 이벤트 로그 */}
            <div className="mt-6 bg-gray-900 rounded-xl p-5">

                <h3 className="text-white font-bold mb-3">
                    📋 이벤트 로그
                </h3>

                <div className="space-y-2">

                    {logs.length === 0

                        ? (
                            <p className="text-gray-400">
                                여기에 이벤트가 찍혀요...
                            </p>
                        )

                        : logs.map((log, i) => (

                            <div
                                key={i}
                                className="
                                    bg-gray-800
                                    text-green-300
                                    px-4
                                    py-2
                                    rounded-lg
                                    text-sm
                                    font-mono
                                "
                            >
                                {log}
                            </div>

                        ))
                    }

                </div>

            </div>

        </div>
    );
}

export default FormEvents;