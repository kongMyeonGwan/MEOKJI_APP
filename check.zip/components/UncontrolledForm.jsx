// 비제어 컴포넌트
// - 입력값을 React state가 아니라 "브라우저(DOM)"가 들고 있는 방식
// - 필요할 때(제출할 때)만 ref로 DOM에서 값을 꺼내 본다.

import { useEffect, useRef, useState } from "react";

function UncontrolledForm() {

  const nameRef = useRef(null);
  const countRef = useRef(null);
  const fileRef = useRef(null);

  // 주문 결과
  const [result, setResult] = useState("");

  // 사진 미리보기 주소
  const [photoUrl, setPhotoUrl] = useState("");


  // 사진을 선택했을 때 실행
  const handleFileChange = () => {

    const files = fileRef.current.files;
    const file = files[0];

    // 파일이 있으면 임시 URL 생성
    setPhotoUrl(
      file ? URL.createObjectURL(file) : ""
    );
  };


  // 기존 blob URL 메모리 해제
  useEffect(() => {

    return () => {

      if (photoUrl) {
        URL.revokeObjectURL(photoUrl);
      }

    };

  }, [photoUrl]);


  const handleSubmit = (e) => {

    e.preventDefault();

    // 제출할 때 DOM에서 값 가져오기
    const name = nameRef.current.value;
    const count = countRef.current.value;
    const files = fileRef.current.files;

    const photo =
      files.length > 0
        ? files[0].name
        : "없음";

    setResult(
      `🧾 ${name}님, 귤 ${count}박스 주문 완료!\n📷 첨부 사진: ${photo}`
    );
  };


  return (
    <div className="mx-auto max-w-2xl rounded-2xl bg-white p-8 shadow-lg">

      <h2 className="mb-8 border-b border-gray-200 pb-5 text-2xl font-bold text-gray-800">
        📝 비제어 컴포넌트 — 귤 주문서
      </h2>


      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >

        {/* 주문자 이름 */}
        <div>

          <label className="mb-2 block text-sm font-semibold text-gray-700">
            주문자 이름
          </label>

          <input
            ref={nameRef}
            defaultValue="귤쌤"
            className="
              w-full
              rounded-lg
              border
              border-gray-300
              px-4
              py-3
              outline-none
              transition
              focus:border-blue-500
              focus:ring-2
              focus:ring-blue-200
            "
          />

        </div>


        {/* 몇 박스 */}
        <div>

          <label className="mb-2 block text-sm font-semibold text-gray-700">
            몇 박스?
          </label>

          <input
            ref={countRef}
            type="number"
            defaultValue={1}
            min={1}
            className="
              w-full
              rounded-lg
              border
              border-gray-300
              px-4
              py-3
              outline-none
              transition
              focus:border-blue-500
              focus:ring-2
              focus:ring-blue-200
            "
          />

        </div>


        {/* 이미지 선택 */}
        <div>

          <label className="mb-2 block text-sm font-semibold text-gray-700">
            귤 사진 선택
          </label>

          <input
            ref={fileRef}
            type="file"
            accept="image/*"

            // ⭐ 사진 선택하면 미리보기 생성
            onChange={handleFileChange}

            className="
              block
              w-full
              cursor-pointer
              rounded-lg
              border
              border-gray-300
              bg-gray-50
              text-sm
              text-gray-700

              file:mr-4
              file:cursor-pointer
              file:border-0
              file:bg-blue-500
              file:px-5
              file:py-3
              file:font-semibold
              file:text-white
              file:transition
              hover:file:bg-blue-600
            "
          />

        </div>


        <button
          type="submit"
          className="
            w-full
            cursor-pointer
            rounded-lg
            bg-orange-500
            px-5
            py-3
            font-bold
            text-white
            shadow
            transition
            hover:bg-orange-600
            active:scale-[0.98]
          "
        >
          🍊 주문하기
        </button>

      </form>


      {/* 결과 */}
      {result && (

        <div className="result">

          {result}

          {photoUrl && (

            <img
              src={photoUrl}
              alt="주문한 귤 사진"
              style={{
                display: "block",
                maxWidth: "100%",
                maxHeight: 200,
                marginTop: 10,
                borderRadius: 6,
              }}
            />

          )}

        </div>

      )}

    </div>
  );
}

export default UncontrolledForm;