// 부모가 자식 컴포넌트를 ref로 조종하기 (useImperativeHandle)
import { useRef, useImperativeHandle } from 'react';


// ========================================
// 자식 컴포넌트 : TV
// React 19에서는 ref를 props처럼 바로 받을 수 있음
// ========================================
function TV({ ref }) {

    const inputRef = useRef(null);

    // 부모에게 사용할 수 있는 기능을 공개
    useImperativeHandle(ref, () => ({
        focus: () => inputRef.current.focus(),

        clear: () => {
            inputRef.current.value = '';
        },

        getValue: () => inputRef.current.value,
    }));


    return (
        <input
            ref={inputRef}
            placeholder="📺 채널 이름 입력"
            className="
                w-full
                px-4 py-3
                border-2 border-gray-300
                rounded-lg
                text-lg
                outline-none
                focus:border-blue-500
                focus:ring-2
                focus:ring-blue-200
                transition
            "
        />
    );
}


// ========================================
// 부모 컴포넌트 : RemoteControl
// ========================================
function RemoteControl() {

    const tvRef = useRef(null);

    return (
        <div className="
            max-w-xl
            mx-auto
            mt-10
            p-8
            bg-white
            rounded-2xl
            shadow-lg
        ">

            <h2 className="text-2xl font-bold text-gray-800 mb-6">
                🎮 리모컨으로 자식 조종하기
            </h2>


            {/* 자식 컴포넌트 */}
            <TV ref={tvRef} />


            {/* 리모컨 버튼 */}
            <div className="flex flex-wrap gap-3 mt-5">

                <button
                    onClick={() => tvRef.current.focus()}
                    className="
                        px-4 py-3
                        bg-blue-500
                        text-white
                        font-semibold
                        rounded-lg
                        hover:bg-blue-600
                        transition
                        cursor-pointer
                    "
                >
                    🔦 포커스
                </button>


                <button
                    onClick={() => tvRef.current.clear()}
                    className="
                        px-4 py-3
                        bg-red-500
                        text-white
                        font-semibold
                        rounded-lg
                        hover:bg-red-600
                        transition
                        cursor-pointer
                    "
                >
                    🧽 지우기
                </button>


                <button
                    onClick={() =>
                        console.log(
                            '현재 값:',
                            tvRef.current.getValue()
                        )
                    }
                    className="
                        px-4 py-3
                        bg-gray-700
                        text-white
                        font-semibold
                        rounded-lg
                        hover:bg-gray-800
                        transition
                        cursor-pointer
                    "
                >
                    📡 값 가져오기(콘솔)
                </button>

            </div>

        </div>
    );
}

export default RemoteControl;