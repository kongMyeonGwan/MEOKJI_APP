// 비밀번호 보기/숨기기  ② 강도 막대  ③ 제출 중 버튼 잠그기
import { useState } from "react";

// 비밀번호 강도 점수 (0~4점): 조건 하나 만족할 때마다 +1
const getStrength = (pw) => {
  let score = 0;

  if (pw.length >= 8) score++;              // 8자 이상
  if (/[a-zA-Z]/.test(pw)) score++;         // 영문 포함
  if (/\d/.test(pw)) score++;               // 숫자 포함
  if (/[^a-zA-Z\d]/.test(pw)) score++;      // 특수문자 포함

  return score;
};


const LABELS = [
  "",
  "😟 약함",
  "😐 보통",
  "🙂 강함",
  "💪 아주 강함"
];


// 강도에 따른 Tailwind 색상
const COLORS = [
  "",
  "bg-red-500",
  "bg-orange-500",
  "bg-yellow-400",
  "bg-green-500"
];


function Usability() {

  const [password, setPassword] = useState("");

  // 비밀번호 보이기 여부
  const [show, setShow] = useState(false);

  // idle → loading → done
  const [status, setStatus] = useState("idle");


  // 비밀번호 강도 계산
  const strength = getStrength(password);


  const handleSubmit = async (e) => {

    e.preventDefault();

    setStatus("loading");

    // 서버에 보내는 척 1.5초 기다리기
    await new Promise((resolve) =>
      setTimeout(resolve, 1500)
    );

    setStatus("done");
  };


  return (

    <div
      className="
        max-w-xl
        mx-auto
        mt-10
        p-8
        bg-white
        border border-orange-100
        rounded-2xl
        shadow-lg
      "
    >

      {/* 제목 */}
      <h2
        className="
          mb-8
          text-2xl
          font-bold
          text-center
          text-orange-500
        "
      >
        ✨ 사용성 — 친절한 비밀번호 입력
      </h2>


      <form onSubmit={handleSubmit}>

        <div className="mb-6">

          {/* 라벨 */}
          <label
            htmlFor="pw"
            className="
              block
              mb-2
              font-semibold
              text-gray-700
            "
          >
            비밀번호
          </label>


          {/* 입력창 + 보기 버튼 */}
          <div className="flex gap-2">

            <input
              id="pw"

              // show가 true면 글자가 보이고
              // false면 비밀번호로 가림
              type={show ? "text" : "password"}

              autoComplete="new-password"

              value={password}

              onChange={(e) => {

                setPassword(e.target.value);

                // 다시 입력하면 완료 상태 초기화
                setStatus("idle");
              }}

              placeholder="영문+숫자+특수문자 8자 이상"

              className="
                flex-1
                px-4 py-3
                border border-gray-300
                rounded-lg
                outline-none
                focus:border-orange-400
                focus:ring-2
                focus:ring-orange-200
              "
            />


            {/* 보기 / 숨기기 */}
            <button
              type="button"

              onClick={() =>
                setShow(!show)
              }

              className="
                px-4
                bg-gray-100
                text-gray-700
                font-semibold
                rounded-lg
                hover:bg-gray-200
                transition
              "
            >

              {show
                ? "🙈 숨기기"
                : "👁️ 보기"
              }

            </button>

          </div>


          {/* 비밀번호 강도 막대 */}
          <div className="flex gap-2 mt-4">

            {[1, 2, 3, 4].map((level) => (

              <div
                key={level}

                className={`
                  h-2
                  flex-1
                  rounded-full
                  transition-all
                  duration-300

                  ${
                    level <= strength
                      ? COLORS[strength]
                      : "bg-gray-200"
                  }
                `}
              />

            ))}

          </div>


          {/* 비밀번호 강도 설명 */}
          <p
            className="
              mt-2
              text-sm
              font-medium
              text-gray-600
            "
          >

            {password
              ? `강도: ${LABELS[strength]}`
              : "비밀번호를 입력해 보세요"
            }

          </p>

        </div>


        {/* 가입 버튼 */}
        <button

          type="submit"

          disabled={
            strength < 3 ||
            status === "loading"
          }

          className="
            w-full
            py-3
            bg-orange-500
            text-white
            font-bold
            rounded-lg
            transition

            hover:bg-orange-600

            disabled:bg-gray-300
            disabled:text-gray-500
            disabled:cursor-not-allowed
          "
        >

          {status === "loading"
            ? "⏳ 가입 중..."
            : "🍊 가입하기"
          }

        </button>

      </form>


      {/* 가입 완료 */}
      {status === "done" && (

        <p
          className="
            mt-6
            p-4
            bg-green-50
            border border-green-200
            text-green-700
            text-center
            font-semibold
            rounded-lg
          "
        >
          🎉 가입 완료! (강함 이상이라 통과)
        </p>

      )}

    </div>
  );
}


export default Usability;