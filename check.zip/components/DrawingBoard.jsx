import { useEffect, useRef } from 'react';

function DrawingBoard() {

    const canvasRef = useRef(null);
    const drawing = useRef(false); // 마우스 버튼을 누르고 있는지 기억

    useEffect(() => {
        const ctx = canvasRef.current.getContext("2d");

        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.strokeStyle = "#ff9800";
    }, []);

    // 마우스 위치를 canvas 기준 좌표로 계산
    const getPos = (e) => {
        const rect = canvasRef.current.getBoundingClientRect();

        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    };

    // 마우스를 눌렀을 때
    const start = (e) => {
        const { x, y } = getPos(e);

        const ctx = canvasRef.current.getContext('2d');

        ctx.beginPath(); // 새로운 선 시작
        ctx.moveTo(x, y); // 펜 위치 이동

        drawing.current = true; // 그리는 중
    };

    // 마우스를 움직일 때
    const move = (e) => {

        // 마우스를 누르지 않았다면 아무것도 하지 않음
        if (!drawing.current) return;

        const { x, y } = getPos(e);

        const ctx = canvasRef.current.getContext('2d');

        ctx.lineTo(x, y); // 현재 위치까지 선 연결
        ctx.stroke();     // 실제 선 그리기
    };

    // 마우스를 뗐을 때
    const stop = () => {
        drawing.current = false;
    };

    // 그림 전체 삭제
    const clear = () => {
        const canvas = canvasRef.current;

        canvas
            .getContext('2d')
            .clearRect(0, 0, canvas.width, canvas.height);
    };

    return (
        <div className="box">

            <h2>🎨 7.1-④ 귤 그림판</h2>

            <p>마우스로 귤을 그려 보세요!</p>

            <canvas
                ref={canvasRef}
                width={400}
                height={250}
                onMouseDown={start}
                onMouseMove={move}
                onMouseUp={stop}
                onMouseLeave={stop}
                style={{
                    border: '2px solid #ccc',
                    cursor: 'crosshair',
                    backgroundColor: 'white'
                }}
            />

            <div>
                <button onClick={clear}>
                    전체지우기
                </button>
            </div>

        </div>
    );
}

export default DrawingBoard;