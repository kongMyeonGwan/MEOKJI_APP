// 제어 컴포넌트
// - 입력값을 React state가 들고 있는 방식 (state -> 화면, 입력 -> state)
// - 값이 state에 있으니 "입력하는 즉시" 미리보기/검사를 할 수 있다.

import { useState } from "react";

// 이메일 모양 검사용 정규식: "글자@글자.글자"
const EMAIL_RULE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function ControlledForm() {

  const [form, setForm] = useState({
    to: "",
    email: "",
    message: ""
  });

  const [sent, setSent] = useState(false);


  // 입력할 때마다 실행
  const handleChange = (e) => {

    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value
    }));

    // 다시 입력하면 "보냄" 표시 제거
    setSent(false);
  };


  // 이메일 유효성 검사
  const emailError =
    form.email && !EMAIL_RULE.test(form.email)
      ? "이메일 형식이 아니에요 (예: gyul@jeju.com)"
      : "";


  // 보내기 버튼 활성화 조건
  const canSend =
    form.to &&
    form.email &&
    !emailError;


  // 폼 제출
  const handleSubmit = (e) => {

    e.preventDefault();

    setSent(true);

    console.log("보낸 편지 : ", form);
  };


  return (
    <div className="mx-auto max-w-2xl rounded-2xl bg-white p-8 shadow-lg">

      {/* 제목 */}
      <h2 className="mb-8 border-b border-gray-200 pb-5 text-2xl font-bold text-gray-800">
        💌 제어 컴포넌트 — 귤 편지 쓰기
      </h2>


      <form
        onSubmit={handleSubmit}
        className="space-y-6"
      >

        {/* 받는 사람 */}
        <div>

          <label className="mb-2 block text-sm font-semibold text-gray-700">
            받는 사람
          </label>

          <input
            name="to"
            value={form.to}
            onChange={handleChange}
            placeholder="예: 한라봉"
            className="
              w-full
              rounded-lg
              border
              border-gray-300
              px-4
              py-3
              outline-none
              transition
              focus:border-orange-500
              focus:ring-2
              focus:ring-orange-200
            "
          />

        </div>


        {/* 이메일 */}
        <div>

          <label className="mb-2 block text-sm font-semibold text-gray-700">
            이메일
          </label>

          <input
            name="email"
            value={form.email}
            onChange={handleChange}
            placeholder="1004@naver.com"
            className={`
              w-full
              rounded-lg
              border
              px-4
              py-3
              outline-none
              transition

              ${
                emailError
                  ? "border-red-500 focus:ring-2 focus:ring-red-200"
                  : "border-gray-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200"
              }
            `}
          />

          {/* 에러가 있을 때만 표시 */}
          {emailError && (
            <p className="mt-2 text-sm font-medium text-red-500">
              ⚠️ {emailError}
            </p>
          )}

        </div>


        {/* 메시지 */}
        <div>

          <label className="mb-2 block text-sm font-semibold text-gray-700">
            편지 내용
          </label>

          <textarea
            name="message"
            value={form.message}
            onChange={handleChange}
            placeholder="귤과 함께 보낼 메시지를 입력하세요."
            rows={5}
            className="
              w-full
              resize-none
              rounded-lg
              border
              border-gray-300
              px-4
              py-3
              outline-none
              transition
              focus:border-orange-500
              focus:ring-2
              focus:ring-orange-200
            "
          />

        </div>


        {/* 보내기 */}
        <button
          type="submit"
          disabled={!canSend}
          className="
            w-full
            rounded-lg
            bg-orange-500
            px-5
            py-3
            font-bold
            text-white
            shadow
            transition
            hover:bg-orange-600
            active:scale-[0.98]
            disabled:cursor-not-allowed
            disabled:bg-gray-300
            disabled:shadow-none
          "
        >
          💌 편지 보내기
        </button>

      </form>


      {/* 전송 완료 */}
      {sent && (
        <div className="mt-6 rounded-lg border border-green-200 bg-green-50 p-4 text-green-700">
          ✅ <strong>{form.to}</strong>님에게 편지를 보냈습니다.
        </div>
      )}

    </div>
  );
}

export default ControlledForm;