import { useState } from "react";

// 체크박스와 radio 버튼 — 귤 주스 주문하기
// radio    : 여러 개 중 "하나만" 선택 → state에 값 하나
// checkbox : 여러 개 "동시에" 선택 → state에 배열

const SIZES = [
    { value: "S", label: "S (300ml)", price: 3000 },
    { value: "M", label: "M (500ml)", price: 4000 },
    { value: "L", label: "L (700ml)", price: 5000 },
];

const TOPPINGS = [
    { id: "ice", label: "🧊 얼음 추가", price: 0 },
    { id: "honey", label: "🍯 꿀", price: 500 },
    { id: "mint", label: "🌿 민트", price: 500 },
    { id: "jelly", label: "🟠 귤 젤리", price: 1000 },
];

function CheckRadio() {

    // radio : 선택된 값 하나
    const [size, setSize] = useState("M");

    // checkbox : 선택된 id 배열
    // 예) ["ice", "honey"]
    const [toppings, setToppings] = useState([]);


    // 토핑 선택 / 선택 해제
    const toggleTopping = (id) => {

        setToppings((prev) =>
            prev.includes(id)
                ? prev.filter((t) => t !== id)
                : [...prev, id]
        );

    };


    // 전체 선택 여부
    const allChecked =
        toppings.length === TOPPINGS.length;


    // 전체 선택 / 전체 해제
    const toggleAll = () =>
        setToppings(
            allChecked
                ? []
                : TOPPINGS.map((t) => t.id)
        );


    // 선택한 사이즈 가격
    const sizePrice =
        SIZES.find((s) => s.value === size).price;


    // 선택한 토핑 가격 합계
    const toppingPrice =
        TOPPINGS
            .filter((t) => toppings.includes(t.id))
            .reduce((sum, t) => sum + t.price, 0);


    // 총 가격
    const total = sizePrice + toppingPrice;


    return (

        <div className="max-w-2xl mx-auto">

            {/* 제목 */}
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
                🍊 체크박스와 Radio - 귤 주스 만들기
            </h2>


            {/* =========================
                사이즈 선택
            ========================= */}
            <fieldset
                className="
                    border
                    border-gray-200
                    rounded-xl
                    bg-gray-50
                    p-6
                    mb-6
                "
            >

                <legend className="px-2 font-bold text-gray-700">
                    🥤 사이즈 (하나만)
                </legend>


                <div className="flex gap-3 mt-3">

                    {SIZES.map((s) => {

                        return (

                            <label
                                key={s.value}
                                className={`
                                    flex-1
                                    flex
                                    items-center
                                    gap-2
                                    p-4
                                    border
                                    rounded-lg
                                    cursor-pointer
                                    transition

                                    ${
                                        size === s.value
                                            ? "border-orange-500 bg-orange-50"
                                            : "border-gray-200 bg-white hover:bg-gray-100"
                                    }
                                `}
                            >

                                <input
                                    type="radio"
                                    name="size"
                                    value={s.value}
                                    checked={size === s.value}

                                    onChange={(e) =>
                                        setSize(e.target.value)
                                    }

                                    className="
                                        w-5
                                        h-5
                                        accent-orange-500
                                        cursor-pointer
                                    "
                                />

                                <div>

                                    <p className="font-semibold text-gray-700">
                                        {s.label}
                                    </p>

                                    <p className="text-sm text-gray-400">
                                        {s.price.toLocaleString()}원
                                    </p>

                                </div>

                            </label>

                        );

                    })}

                </div>

            </fieldset>


            {/* =========================
                추가 재료
            ========================= */}
            <fieldset
                className="
                    border
                    border-gray-200
                    rounded-xl
                    bg-gray-50
                    p-6
                    mb-6
                "
            >

                <legend className="px-2 font-bold text-gray-700">
                    ✨ 추가 재료 (여러 개)
                </legend>


                {/* 전체 선택 */}
                <label
                    className="
                        flex
                        items-center
                        gap-3
                        p-4
                        mt-3
                        mb-4
                        bg-orange-50
                        border
                        border-orange-200
                        rounded-lg
                        cursor-pointer
                        font-bold
                    "
                >

                    <input
                        type="checkbox"
                        checked={allChecked}
                        onChange={toggleAll}

                        className="
                            w-5
                            h-5
                            accent-orange-500
                            cursor-pointer
                        "
                    />

                    전체 선택

                </label>


                {/* 토핑 목록 */}
                <div className="space-y-3">

                    {TOPPINGS.map((t) => {

                        return (

                            <label
                                key={t.id}
                                className={`
                                    flex
                                    items-center
                                    justify-between
                                    p-4
                                    border
                                    rounded-lg
                                    cursor-pointer
                                    transition

                                    ${
                                        toppings.includes(t.id)
                                            ? "border-orange-400 bg-orange-50"
                                            : "border-gray-200 bg-white hover:bg-gray-100"
                                    }
                                `}
                            >

                                <div className="flex items-center gap-3">

                                    <input
                                        type="checkbox"

                                        checked={
                                            toppings.includes(t.id)
                                        }

                                        onChange={() =>
                                            toggleTopping(t.id)
                                        }

                                        className="
                                            w-5
                                            h-5
                                            accent-orange-500
                                            cursor-pointer
                                        "
                                    />

                                    <span className="font-semibold text-gray-700">
                                        {t.label}
                                    </span>

                                </div>


                                <span className="text-sm text-gray-500">

                                    {t.price === 0
                                        ? "무료"
                                        : `+${t.price.toLocaleString()}원`
                                    }

                                </span>

                            </label>

                        );

                    })}

                </div>

            </fieldset>


            {/* =========================
                결과
            ========================= */}
            <div
                className="
                    bg-gray-900
                    text-white
                    rounded-xl
                    p-6
                "
            >

                <h3 className="text-lg font-bold mb-4">
                    🧾 주문 결과
                </h3>


                <div className="flex justify-between mb-3">

                    <span className="text-gray-400">
                        🧃 선택
                    </span>

                    <span className="font-semibold">
                        {size} 사이즈 + {toppings.length}개 추가
                    </span>

                </div>


                <div
                    className="
                        flex
                        justify-between
                        items-center
                        pt-4
                        border-t
                        border-gray-700
                    "
                >

                    <span className="font-bold">
                        💰 총 가격
                    </span>

                    <span className="text-2xl font-bold text-orange-400">
                        {total.toLocaleString()}원
                    </span>

                </div>

            </div>

        </div>
    );
}

export default CheckRadio;