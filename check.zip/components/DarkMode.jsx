// body 태그에 클래스 붙였다 떼기 (전역 스타일)
import { useState, useEffect } from 'react';

function DarkMode() {

  const [dark, setDark] = useState(false);

  useEffect(() => {

    if (!dark) return;

    // body에 dark 클래스 추가
    document.body.classList.add('dark');

    // Tailwind로 실제 body 색상 변경
    document.body.classList.add('bg-gray-900', 'text-white');

    console.log('🌙 body에 dark 클래스 추가');

    // 정리: 라이트로 바꾸거나 다른 메뉴로 가면 클래스 제거
    return () => {

      document.body.classList.remove('dark');

      document.body.classList.remove(
        'bg-gray-900',
        'text-white'
      );

      console.log('☀️ body에서 dark 클래스 제거');
    };

  }, [dark]);


  return (
    <div
      className={`
        max-w-xl
        mx-auto
        p-8
        rounded-2xl
        shadow-lg
        transition-all
        duration-300

        ${
          dark
            ? 'bg-gray-800 text-white'
            : 'bg-white text-gray-800'
        }
      `}
    >

      <h2 className="text-2xl font-bold mb-4">
        🌙 7.3-② 다크 모드 스위치
      </h2>

      <p
        className={`
          mb-6
          ${dark ? 'text-gray-300' : 'text-gray-600'}
        `}
      >
        이 컴포넌트는 자기 밖에 있는 &lt;body&gt; 색을 바꿉니다.
      </p>


      <button
        onClick={() => setDark(!dark)}
        className={`
          px-5
          py-3
          rounded-lg
          font-semibold
          transition
          cursor-pointer

          ${
            dark
              ? 'bg-yellow-400 text-gray-900 hover:bg-yellow-300'
              : 'bg-gray-800 text-white hover:bg-gray-700'
          }
        `}
      >
        {dark ? '☀️ 라이트 모드' : '🌙 다크 모드'}
      </button>


      <p
        className={`
          mt-6
          text-sm
          ${dark ? 'text-gray-400' : 'text-gray-500'}
        `}
      >
        다크 모드를 켠 채로 다른 메뉴를 눌러 보세요.
        정리 함수 덕분에 원래대로 돌아옵니다.
      </p>

    </div>
  );
}

export default DarkMode;