import { useRef, useEffect, useState} from 'react';
import Chart from "chart.js/auto";

function FruitChart (){
    const canvasRef = useRef(null);
    const [sales, setSales] = useState([12,19,7,15]);

    useEffect(() => {
        const chart = new Chart(canvasRef.current, {
            type: 'bar',
            data:{
                labels: ['🍊 귤', '🍎 사과', '🍌 바나나', '🍇 포도'],
                datasets: [{ label: '오늘 판매량 (개)', data: sales, backgroundColor: '#ff9800' }],
            },
        });
        console.log('차트 생성');

        return () => {
            chart.destroy(); // 다시 그리기 전에 차트 삭제
            console.log("차트 삭제");
        }
    },[sales]); // 판매량이 변동되면 차트가 바뀜

    const shuffle = () => {
        setSales(sales.map(() => Math.floor(Math.random() * 20) + 1 ));
    };

    return (
        <div className="box">
        <h2>📊 7.2 과일가게 판매 차트 (Chart.js)</h2>
        <div style={{ maxWidth: 500 }}>
            <canvas ref={canvasRef} />
        </div>
        <button onClick={shuffle}>🎲 판매량 랜덤 변경</button>
        </div>
    );


    
}

export default FruitChart;