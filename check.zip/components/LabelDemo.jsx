import { useState } from "react";

function LabelDemo() {

    const [nick, setNick] = useState("");
    const [fruit, setFruit] = useState("");
    const [agree, setAgree] = useState(false);

    return (
        <div className="max-w-2xl mx-auto">

            {/* 제목 */}
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
                🏷️ 레이블 — 글자를 눌러 보세요
            </h2>


            {/* 닉네임 */}
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-5">

                <label
                    htmlFor="nick"
                    className="block font-semibold text-gray-700 mb-2"
                >
                    닉네임
                    <span className="text-red-500 ml-1">
                        *
                    </span>
                </label>

                <input
                    id="nick"
                    type="text"
                    value={nick}

                    onChange={(e) =>
                        setNick(e.target.value)
                    }

                    aria-describedby="nick-help"
                    required
                    placeholder="닉네임을 입력하세요"

                    className="
                        w-full
                        px-4
                        py-3
                        bg-white
                        border
                        border-gray-300
                        rounded-lg
                        outline-none
                        text-gray-800
                        focus:border-blue-500
                        focus:ring-2
                        focus:ring-blue-200
                        transition
                    "
                />

                <p
                    id="nick-help"
                    className="text-sm text-gray-400 mt-2"
                >
                    2~10자, 한글/영어 가능
                </p>

            </div>


            {/* 좋아하는 과일 */}
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-5">

                <label
                    htmlFor="fruit"
                    className="block font-semibold text-gray-700 mb-2"
                >
                    🍊 좋아하는 과일
                </label>

                <input
                    id="fruit"
                    type="text"
                    value={fruit}

                    onChange={(e) =>
                        setFruit(e.target.value)
                    }

                    placeholder="예: 귤"

                    className="
                        w-full
                        px-4
                        py-3
                        bg-white
                        border
                        border-gray-300
                        rounded-lg
                        outline-none
                        text-gray-800
                        focus:border-orange-500
                        focus:ring-2
                        focus:ring-orange-200
                        transition
                    "
                />

                <p className="text-sm text-gray-400 mt-2">
                    좋아하는 과일을 입력해주세요.
                </p>

            </div>


            {/* 소식 받기 */}
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 mb-5">

                <label
                    htmlFor="agree"
                    className="
                        flex
                        items-center
                        gap-3
                        cursor-pointer
                    "
                >

                    <input
                        id="agree"
                        type="checkbox"
                        checked={agree}

                        onChange={(e) =>
                            setAgree(e.target.checked)
                        }

                        className="
                            w-5
                            h-5
                            accent-blue-500
                            cursor-pointer
                        "
                    />

                    <span className="font-semibold text-gray-700">
                        📩 새로운 소식 받기
                    </span>

                </label>

                <p className="text-sm text-gray-400 mt-2 ml-8">
                    체크하면 새로운 소식을 받을 수 있습니다.
                </p>

            </div>


            {/* 결과 */}
            <div className="bg-gray-900 text-white rounded-xl p-6">

                <h3 className="font-bold text-lg mb-4">
                    📋 입력 결과
                </h3>

                <div className="space-y-2">

                    <p>
                        <span className="text-gray-400">
                            닉네임:
                        </span>{" "}

                        <span className="font-semibold">
                            {nick || "-"}
                        </span>
                    </p>


                    <p>
                        <span className="text-gray-400">
                            과일:
                        </span>{" "}

                        <span className="font-semibold">
                            {fruit || "-"}
                        </span>
                    </p>


                    <p>
                        <span className="text-gray-400">
                            소식 받기:
                        </span>{" "}

                        <span
                            className={
                                agree
                                    ? "font-semibold text-green-400"
                                    : "font-semibold text-red-400"
                            }
                        >
                            {agree ? "예" : "아니오"}
                        </span>
                    </p>

                </div>

            </div>

        </div>
    );
}

export default LabelDemo;