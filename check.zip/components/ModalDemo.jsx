import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';

function Modal({ onClose, children }) {

    useEffect(() => {
        // body에 영향 주기: 뒤쪽 화면 스크롤 막기 + ESC키로 닫기
        document.body.style.overflow = "hidden";

        const onKey = (e) => {
            if (e.key === "Escape") onClose();
        };

        document.addEventListener("keydown", onKey);

        console.log("🔒 스크롤 잠금, ESC 리스너 등록");

        // 모달이 사라지면 원래대로
        return () => {
            document.body.style.overflow = "";
            document.removeEventListener("keydown", onKey);
        };
    }, [onClose]);

    // document.body에 그린다 → 부모 div 밖으로 탈출!
    return createPortal(
        <div
            onClick={onClose}
            className="
                fixed
                inset-0
                bg-black/50
                grid
                place-items-center
                z-50
            "
        >
            {/* 클릭 이벤트가 바깥 영역으로 전달되지 않게 막음 */}
            <div
                onClick={(e) => e.stopPropagation()}
                className="
                    bg-white
                    text-gray-800
                    p-6
                    rounded-xl
                    shadow-2xl
                    min-w-[320px]
                    text-center
                "
            >
                {children}
            </div>
        </div>,
        document.body
    );
}


function ModalDemo() {

    const [open, setOpen] = useState(false);

    return (
        <div
            className="
                overflow-hidden
                max-w-2xl
                mx-auto
                p-8
                bg-white
                rounded-2xl
                shadow-lg
            "
        >

            <h2 className="text-2xl font-bold text-gray-800 mb-4">
                🎁 7.3-① 선물 상자 모달 (Portal)
            </h2>

            <p className="text-gray-600 mb-6">
                이 상자는 overflow: hidden 이지만,
                모달은 body에 그려져서 잘리지 않아요.
            </p>

            <button
                onClick={() => setOpen(true)}
                className="
                    px-5
                    py-3
                    bg-orange-500
                    text-white
                    font-semibold
                    rounded-lg
                    hover:bg-orange-600
                    transition
                    cursor-pointer
                "
            >
                🎁 선물 열기
            </button>


            {open && (
                <Modal onClose={() => setOpen(false)}>

                    <h3 className="text-2xl font-bold mb-4">
                        🎉 축하합니다!
                    </h3>

                    <p className="text-lg mb-2">
                        귤 한 박스 🍊🍊🍊 당첨!
                    </p>

                    <p className="text-sm text-gray-500">
                        (ESC 키나 바깥을 눌러도 닫혀요)
                    </p>

                </Modal>
            )}

        </div>
    );
}

export default ModalDemo;