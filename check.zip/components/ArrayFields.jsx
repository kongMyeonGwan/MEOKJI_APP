import { useState, useRef } from "react";

function ArrayFields() {
  // 친구 한명 = { id, name, boxes }
  const [friends, setFriends] = useState([
    { id: 1, name: "", boxes: 1 }
  ]);

  // 새 친구에게 줄 id
  const nextId = useRef(2);

  // 친구 정보 변경
  const handleChange = (id, field, value) => {
    setFriends((prev) =>
      prev.map((f) =>
        f.id === id
          ? { ...f, [field]: value }
          : f
      )
    );
  };

  // 친구 추가
  const addFriend = () => {
    setFriends((prev) => [
      ...prev,
      {
        id: nextId.current,
        name: "",
        boxes: 1
      }
    ]);

    nextId.current += 1;
  };

  // 친구 삭제
  const removeFriend = (id) => {
    setFriends((prev) =>
      prev.filter((f) => f.id !== id)
    );
  };

  // 총 박스 수
  const totalBoxes = friends.reduce(
    (sum, f) => sum + Number(f.boxes),
    0
  );

  return (
    <div className="min-h-screen bg-orange-50 p-8">
      <div className="mx-auto max-w-3xl rounded-2xl bg-white p-8 shadow-lg">

        {/* 제목 */}
        <h2 className="mb-6 text-2xl font-bold text-orange-600">
          🍊 귤 선물 명단
        </h2>

        {/* 친구 목록 */}
        <div className="space-y-4">

          {friends.map((f, index) => (
            <div
              key={f.id}
              className="
                flex items-center gap-3
                rounded-xl
                border border-orange-200
                bg-orange-50
                p-4
              "
            >

              {/* 친구 번호 */}
              <strong className="w-20 text-gray-700">
                친구 {index + 1}
              </strong>

              {/* 이름 */}
              <input
                type="text"
                name={`friends[${index}].name`}
                value={f.name}
                placeholder="이름"
                onChange={(e) =>
                  handleChange(
                    f.id,
                    "name",
                    e.target.value
                  )
                }
                className="
                  flex-1
                  rounded-lg
                  border border-gray-300
                  bg-white
                  px-4 py-2
                  outline-none
                  transition
                  focus:border-orange-400
                  focus:ring-2
                  focus:ring-orange-200
                "
              />

              {/* 박스 수 */}
              <input
                type="number"
                name={`friends[${index}].boxes`}
                value={f.boxes}
                min={1}
                onChange={(e) =>
                  handleChange(
                    f.id,
                    "boxes",
                    e.target.value
                  )
                }
                className="
                  w-20
                  rounded-lg
                  border border-gray-300
                  bg-white
                  px-3 py-2
                  text-center
                  outline-none
                  transition
                  focus:border-orange-400
                  focus:ring-2
                  focus:ring-orange-200
                "
              />

              <span className="text-sm text-gray-500">
                박스
              </span>

              {/* 친구가 2명 이상일 때만 삭제 */}
              {friends.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeFriend(f.id)}
                  className="
                    rounded-lg
                    bg-red-100
                    px-3 py-2
                    text-sm
                    font-semibold
                    text-red-600
                    transition
                    hover:bg-red-200
                  "
                >
                  ❌ 삭제
                </button>
              )}

            </div>
          ))}

        </div>

        {/* 친구 추가 */}
        <button
          type="button"
          onClick={addFriend}
          className="
            mt-6
            w-full
            rounded-xl
            bg-orange-500
            py-3
            font-bold
            text-white
            transition
            hover:bg-orange-600
            active:scale-[0.99]
          "
        >
          + 친구 추가
        </button>

        {/* 결과 */}
        <div
          className="
            mt-6
            rounded-xl
            border border-orange-200
            bg-orange-50
            p-5
          "
        >
          <p className="text-lg font-semibold text-gray-700">
            🎁 {friends.length}명에게 총{" "}
            <span className="font-bold text-orange-600">
              {totalBoxes}박스
            </span>{" "}
            보내기
          </p>

          <p className="mt-2 text-sm text-gray-500">
            받는 사람 :{" "}
            {friends
              .map((f) => f.name || "(이름 없음)")
              .join(", ")}
          </p>
        </div>

      </div>
    </div>
  );
}

export default ArrayFields;