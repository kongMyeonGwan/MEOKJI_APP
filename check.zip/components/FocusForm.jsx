// 포커스 — 인증번호 4칸: 숫자를 치면 다음 칸으로 자동 이동
//  - 여러 input을 ref 배열로 관리
import { useState, useRef, useEffect } from "react";

const LENGTH = 4; // 칸 수
const ANSWER = "1234"; // 연습용 정답

function FocusForm() {
  const [digits, setDigits] = useState(Array(LENGTH).fill("")); // ['', '', '', '']
  const [message, setMessage] = useState("");
  const inputsRef = useRef([]); // input 4개를 담을 배열 상자

  // 화면이 열리면 첫 칸에 커서
  useEffect(() => {
    inputsRef.current[0].focus();
  }, []);

  // 숫자를 입력하면 저장하고 다음 칸으로 이동
  const handleChange = (index, e) => {
    const value = e.target.value.replace(/\D/g, "").slice(-1); // 숫자만, 마지막 한 글자만
    const next = [...digits]; // 배열 복사 후 수정
    next[index] = value;
    setDigits(next);

    if (value && index < LENGTH - 1) {
      inputsRef.current[index + 1].focus(); // 다음 칸으로!
    }
  };

  // 빈 칸에서 Backspace → 이전 칸으로 이동
  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && !digits[index] && index > 0) {
      inputsRef.current[index - 1].focus();
    }
  };

  // 제출: 빈 칸이 있으면 그 칸으로 포커스 이동
  const handleSubmit = (e) => {
    e.preventDefault();
    const emptyIndex = digits.findIndex((d) => d === ""); // 첫 번째 빈 칸 번호 (없으면 -1)
    if (emptyIndex !== -1) {
      setMessage(`⚠️ ${emptyIndex + 1}번째 칸이 비었어요`);
      inputsRef.current[emptyIndex].focus();
      return;
    }
    if (digits.join("") === ANSWER) {
      setMessage("🎉 인증 성공!");
    } else {
      setMessage("❌ 번호가 틀렸어요. 다시 입력하세요");
      setDigits(Array(LENGTH).fill("")); // 전부 지우고
      inputsRef.current[0].focus(); // 첫 칸으로
    }
  };

  return (
    <div className="box">
      <h2>🔐 포커스 — 인증번호 입력</h2>
      <p className="help">문자로 온 번호는 1234 예요 😉</p>

      <form onSubmit={handleSubmit}>
        <div className="otp">
          {digits.map((d, i) => (
            <input
              key={i} // 칸 순서가 바뀌지 않으니 index key OK
              ref={(el) => {
                inputsRef.current[i] = el;
              }} // i번째 칸 저장
              value={d}
              inputMode="numeric" // 휴대폰에서 숫자 키패드
              aria-label={`${i + 1}번째 숫자`} // 라벨이 없는 칸을 위한 이름
              onChange={(e) => handleChange(i, e)}
              onKeyDown={(e) => handleKeyDown(i, e)}
            />
          ))}
        </div>
        <button type="submit">확인</button>
      </form>

      {message && <p className="result">{message}</p>}
    </div>
  );
}

export default FocusForm;
