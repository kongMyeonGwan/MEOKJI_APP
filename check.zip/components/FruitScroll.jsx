import { useRef } from 'react';

const fruits = ['🍊 귤', '🍎 사과', '🍌 바나나', '🍇 포도', '🍉 수박'];

function FruitScroll() {

    const itemRef = useRef([]);

    // index: 몇 번째 과일로 갈지 (0~4)
    const goTo = (index) => {
        itemRef.current[index].scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    };

    return (
        <div className="bg-white rounded-xl shadow-md p-6">

            <h2 className="text-2xl font-bold mb-5">
                🚀 1 과일 순간이동
            </h2>

            {/* 과일 선택 버튼 */}
            <div className="flex gap-2 mb-3">
                {fruits.map((fruit, i) => (
                    <button
                        key={fruit}
                        onClick={() => goTo(i)}
                        className="
                            px-4 py-2
                            bg-orange-500
                            text-white
                            rounded-lg
                            font-semibold
                            hover:bg-orange-600
                            cursor-pointer
                            transition
                        "
                    >
                        {fruit}
                    </button>
                ))}
            </div>

            {/* 강의의 스크롤 영역 */}
            <div className="
                h-[250px]
                overflow-auto
                border
                border-gray-300
                rounded-lg
                mt-3
                p-3
                bg-gray-50
            ">

                {fruits.map((fruit, i) => (
                    <div
                        key={fruit}
                        ref={(el) => itemRef.current[i] = el}
                        className="
                            h-32
                            flex
                            items-center
                            justify-center
                            mb-3
                            bg-white
                            border
                            border-gray-200
                            rounded-lg
                            text-2xl
                            font-bold
                        "
                    >
                     {fruit}
                    </div>
               
                ))}

            </div>

        </div>
    );
}

export default FruitScroll;